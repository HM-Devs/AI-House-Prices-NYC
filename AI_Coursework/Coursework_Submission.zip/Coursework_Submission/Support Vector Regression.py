# -*- coding: utf-8 -*-
"""
Created on Thu Dec 1 11:30:21 2019

@author: Junad
This script is for SVM regression. 
I used an online tutorial to go about doing this.
https://medium.com/coinmonks/support-vector-regression-or-svr-8eb3acf6d0ff
This script contains different ways (as functions) to predict the sale price based on
1 feature or all the features. They each produce different results and have different scores
of accuracy and RMSE value. They also produce a bar chart showing the actual result 
and the predicted results upon executing the model. 

The script is run by calling each function in order of best to worst results.

"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from sklearn import preprocessing
from sklearn import metrics
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA  

# import warnings filter
from warnings import simplefilter
# ignore all future warnings
simplefilter(action='ignore', category=FutureWarning)
simplefilter(action='ignore', category=DeprecationWarning)

path = ""

filename_read = os.path.join(path, "nyc-rolling-sales.csv")
df = pd.read_csv(filename_read, na_values=['NA', ' -  ']) #making null values as NA

#converting date field values to dd-mm-yyyy
df['SALE DATE'] = pd.to_datetime(df['SALE DATE'], dayfirst=True)
#sorting by sale date
df = df.sort_values(by='SALE DATE', ascending=True)

"""
Removing certain types of buildings which are public buildings like hospitals as we 
want to focus on homes which anyone could purchase as opposed to warehouses and such
"""
#Encode building class category column as numerical to filter this column
leB = preprocessing.LabelEncoder() 
buildingEncode = leB.fit(df['BUILDING CLASS CATEGORY']) #fit the data
buildingEncode = leB.transform(df['BUILDING CLASS CATEGORY']) #transform/encode the data to numerical
df['BUILDING CLASS CATEGORY'] = buildingEncode #assign the encoded column to the dataset
#remove properties that have building class category of 21 and above
df = df[df['BUILDING CLASS CATEGORY'].astype('float') <= 18] #when encoding, 21 OFFICE BUILDINGS is encoded as 19. So 18 and less                       


"""Data filtering removing things we don't want to keep to use with the models."""
#Divide the sale price values by a million so the numbers aren't large
df['SALE PRICE'] = df['SALE PRICE'].div(1000000)
#drop the rows that have 0 as the sale price
df = df[df['SALE PRICE'] != 0] #$0 properties are those where the wnership was transfered to family members and not sold
df = df[df['GROSS SQUARE FEET'] != 0]
df = df[df['SALE PRICE'] != 0.00001]
#removing big sale price values because the scale of the graphs are too high for me
df = df[(df['SALE PRICE'] <= 10)]
#removing gross square feet numbers bigger than 2000 cos the scale is too bigh
df = df[(df['GROSS SQUARE FEET'] <= 2000)]
#------------------------------------------------------------
"""
This is for the second dataframe where we reduce the columns and clean up further.
"""
#creating a new dataframe with the columns we feel are useful
col_borough = df['BOROUGH']
col_neighborhood = df['NEIGHBORHOOD'] 
col_buildingClassCat = df['BUILDING CLASS CATEGORY']
col_taxClassPresent = df['TAX CLASS AT PRESENT']
col_block = df['BLOCK']
col_lot = df['LOT']
col_buildingClassPresent = df['BUILDING CLASS AT PRESENT']
col_grossSqFt = df['GROSS SQUARE FEET']
col_yearBuilt = df['YEAR BUILT']
col_taxClassSale = df['TAX CLASS AT TIME OF SALE']
col_buildingClassSale = df['BUILDING CLASS AT TIME OF SALE']
col_salePrice = df['SALE PRICE']
col_saleDate = df['SALE DATE']

dfCon = pd.concat([col_borough, col_neighborhood, col_buildingClassCat, 
                   col_taxClassPresent, col_block, col_lot, col_buildingClassPresent, 
                   col_grossSqFt, col_yearBuilt, col_taxClassSale, col_buildingClassSale, 
                   col_salePrice, col_saleDate], axis = 1)

#converting date field values to dd-mm-yyyy
dfCon['SALE DATE'] = pd.to_datetime(dfCon['SALE DATE'], dayfirst=True)
#sorting by sale date
dfCon = dfCon.sort_values(by='SALE DATE', ascending=True)
#filling missing values with median for sale price and gross square feet
med = dfCon['SALE PRICE'].median()
dfCon['SALE PRICE'] = dfCon['SALE PRICE'].fillna(med) #this replaces all the NA  values in sale price with 530000 which is the median of the sale price column
med2 = dfCon['GROSS SQUARE FEET'].median()
dfCon['GROSS SQUARE FEET'] = dfCon['GROSS SQUARE FEET'].fillna(med2)

"""
Encoding the string categorical data and changing the data types to either categorical 
or numerical.
"""

dfEncode = dfCon
#Rename the columns to lower case so it's easier to type.
dfEncode.columns = ['borough', 'neighborhood', 'building_class_category',
       'tax_class_at_present', 'block', 'lot', 'building_class_at_present',
       'gross_square_feet', 'year_built', 'tax_class_at_time_of_sale',
       'building_class_at_time_of_sale', 'sale_price', 'sale_date']

"""
Encoding the string categorical data into numerical data so they can be used in the models.
The data types will be changed to numerical or categorical later.
"""
#Neighborhood
leN = preprocessing.LabelEncoder() #one variable for encoding neighborhood column
neighborEncode = leN.fit(dfEncode['neighborhood']) #fit the data
neighborEncode = leN.transform(dfEncode['neighborhood']) #transform/encode the data to numerical
dfEncode['neighborhood'] = neighborEncode #replace the values in neighborhood column with the encoded values
#Tax Class at present
leT = preprocessing.LabelEncoder()
taxEncode = leT.fit(dfEncode['tax_class_at_present'])
taxEncode = leT.transform(dfEncode['tax_class_at_present'])
dfEncode['tax_class_at_present'] = taxEncode
#Building class at present
leBP = preprocessing.LabelEncoder() 
buildingPEncode = leBP.fit(dfEncode['building_class_at_present'])
buildingPEncode = leBP.transform(dfEncode['building_class_at_present'])
dfEncode['building_class_at_present'] = buildingPEncode
#Building class at time of sale
leBS = preprocessing.LabelEncoder()
buildingTEncode = leBS.fit(dfEncode['building_class_at_time_of_sale'])
buildingTEncode = leBS.transform(dfEncode['building_class_at_time_of_sale'])
dfEncode['building_class_at_time_of_sale'] = buildingTEncode
#Sale date
leSD = preprocessing.LabelEncoder() #sale date
dateEncode = leSD.fit(dfEncode['sale_date']) #fit the data
dateEncode = leSD.transform(dfEncode['sale_date']) #transform/encode the data to numerical
dfEncode['sale_date'] = dateEncode 

#Converting data types to numerical and categorical as couldn't be done in df and move to dfEncode
dfEncode['sale_price'] = pd.to_numeric(dfEncode['sale_price'], errors = 'coerce')
dfEncode['gross_square_feet'] = pd.to_numeric(dfEncode['gross_square_feet'], errors = 'coerce')
#categorical data
dfEncode['borough'] = dfEncode['borough'].astype('category')
dfEncode['neighborhood'] = dfEncode['neighborhood'].astype('category')
dfEncode['building_class_category'] = dfEncode['building_class_category'].astype('category')

dfEncode['tax_class_at_present'] = dfEncode['tax_class_at_present'].astype('category')
dfEncode['tax_class_at_time_of_sale'] = dfEncode['tax_class_at_time_of_sale'].astype('category')
dfEncode['building_class_at_present'] = dfEncode['building_class_at_present'].astype('category')
dfEncode['building_class_at_time_of_sale'] = dfEncode['building_class_at_time_of_sale'].astype('category')

df = dfEncode #assign the cleaned up data to the main dataframe

#separate dataframes for each borough.
df1 = df[df.borough==1] #Manhattan
df2 = df[df.borough==2] #Bronx
df3 = df[df.borough==3] #Brooklyn
df4 = df[df.borough==4] #Queens
df5 = df[df.borough==5] #Staten Island

"""
Here is where support vecotr regression is attempted.
3 main approaches were done, each for both using linear kernel and RBF kernel.
svrLin and svrRBF: Using 1 feature - Gross square feet column - to predict sale prices.
svr2Lin and svr2RBF: Using all the other features to predict sale prices.
svr3Lin and svr3RBF: Using PCA in an attempt to make the results for attempt 2 better.
"""

def svrLin(): #Using gross square feet
    print("\nsvrLin")
    regressor = SVR(kernel = 'linear', degree = 1)
    X = df.gross_square_feet.values.reshape(-1, 1) #selecting gross square feet
    y = df.sale_price.values.reshape(-1, 1).ravel() #predicting sale price
    # Scale X alone
    sc_X = StandardScaler()
    X = sc_X.fit_transform(X)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 7)
    regressor.fit(X_train, y_train)
    y_pred = regressor.predict(X_test)
    #Display the scores and mean results and RMSE.
    print(f"Accuracy Score: {regressor.score(X_test, y_test)}")
    print(f"R2 Score: {r2_score(y_test, y_pred)}")
    print('Mean Absolute Error: ', metrics.mean_absolute_error(y_test, y_pred))
    print('Mean Squared Error: ', metrics.mean_squared_error(y_test, y_pred))
    print('Mean: ', np.mean(y_test))
    print('Root Mean Squared Error: ', np.sqrt(metrics.mean_squared_error(y_test, y_pred)))
    #Create a dataframe to see the predicted results and compare with the expected
    results = pd.DataFrame({'Actual' : y_test, 'Predicted' : y_pred})
    print(results)
    #bar chart for actual vs predicted. Shows first 100 entries. 
    results[0:100].plot(kind = 'bar', figsize= (10, 8))
    plt.grid(which = 'major', linestyle = '-', linewidth = '0.5', color = 'green')
    plt.grid(which = 'minor', linestyle = ':', linewidth = '0.5', color = 'black')
    plt.title('Predicting vs Actual sale prices in millions $')
    plt.xlabel('Gross square feet')
    plt.ylabel('House Prices in millions ($)')
    plt.show()

def svrRBF(): #4th best
    print("\nsvrRBF")
    regressor = SVR(kernel = 'rbf', C = 10)
    X = df.gross_square_feet.values.reshape(-1, 1)#selecting gross square feet
    y = df.sale_price.values.reshape(-1, 1).ravel()#predicting sale price
    # Scale X alone
    sc_X = StandardScaler()
    X = sc_X.fit_transform(X)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 7)
    regressor.fit(X_train, y_train)
    y_pred = regressor.predict(X_test)
    #Display the scores and mean results and RMSE.
    print(f"Accuracy Score: {regressor.score(X_test, y_test)}")
    print(f"R2 Score: {r2_score(y_test, y_pred)}")
    print('Mean Absolute Error: ', metrics.mean_absolute_error(y_test, y_pred))
    print('Mean Squared Error: ', metrics.mean_squared_error(y_test, y_pred))
    print('Mean: ', np.mean(y_test))
    print('Root Mean Squared Error: ', np.sqrt(metrics.mean_squared_error(y_test, y_pred)))
    #Create a dataframe to see the predicted results and compare with the expected
    results = pd.DataFrame({'Actual' : y_test, 'Predicted' : y_pred})
    print(results)
    #bar chart for actual vs predicted. Shows first 100 entries. 
    results[0:100].plot(kind = 'bar', figsize= (10, 8))
    plt.grid(which = 'major', linestyle = '-', linewidth = '0.5', color = 'green')
    plt.grid(which = 'minor', linestyle = ':', linewidth = '0.5', color = 'black')
    plt.title('Predicting vs Actual sale prices in millions $')
    plt.xlabel('Data')
    plt.ylabel('House Prices in millions ($)')
    plt.show()

#here, I'm going to try the same as before but this time, using all features   
def svr2Lin(): #2nd best
    print("\nsvr2Lin")
    regressor = SVR(kernel = 'linear', degree = 1)
    X = df.drop('sale_price', axis = 1) #using all features
    y = df.sale_price #predicting sale price
    #Scaling X
    sc_X = StandardScaler()
    X = sc_X.fit_transform(X)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 7)
    regressor.fit(X_train, y_train)
    y_pred = regressor.predict(X_test)
    #Display the scores and mean results and RMSE.
    print(f"Accuracy Score: {regressor.score(X_test, y_test)}")
    print(f"R2 Score: {r2_score(y_test, y_pred)}")
    print('Mean Absolute Error: ', metrics.mean_absolute_error(y_test, y_pred))
    print('Mean Squared Error: ', metrics.mean_squared_error(y_test, y_pred))
    print('Mean: ', np.mean(y_test))
    print('Root Mean Squared Error: ', np.sqrt(metrics.mean_squared_error(y_test, y_pred)))
    #Create a dataframe to see the predicted results and compare with the expected
    results = pd.DataFrame({'Actual' : y_test, 'Predicted' : y_pred})
    results = results.reset_index() #reset the index back to 0
    results = results.drop('index', axis = 1)#remove addditional index column created
    print(results)
    #bar chart for actual vs predicted. Shows first 100 entries.
    results[0:100].plot(kind = 'bar', figsize= (10, 8))
    plt.grid(which = 'major', linestyle = '-', linewidth = '0.5', color = 'green')
    plt.grid(which = 'minor', linestyle = ':', linewidth = '0.5', color = 'black')
    plt.title('Predicting vs Actual sale prices in millions $')
    plt.xlabel('Data')
    plt.ylabel('House Prices in millions ($)')
    plt.show()
    
def svr2RBF(): #best
    print("\nsvr2RBF")
    regressor = SVR(kernel = 'rbf', C = 10)
    X = df.drop('sale_price', axis = 1) #using all features
    y = df.sale_price #predicting sale price
    #Scaling X
    sc_X = StandardScaler()
    X = sc_X.fit_transform(X)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 7)
    regressor.fit(X_train, y_train)
    y_pred = regressor.predict(X_test)
    #Display the scores and mean results and RMSE.
    print(f"Accuracy Score: {regressor.score(X_test, y_test)}")
    print(f"R2 Score: {r2_score(y_test, y_pred)}")
    print('Mean Absolute Error: ', metrics.mean_absolute_error(y_test, y_pred))
    print('Mean Squared Error: ', metrics.mean_squared_error(y_test, y_pred))
    print('Mean: ', np.mean(y_test))
    print('Root Mean Squared Error: ', np.sqrt(metrics.mean_squared_error(y_test, y_pred)))
    #Create a dataframe to see the predicted results and compare with the expected
    results = pd.DataFrame({'Actual' : y_test, 'Predicted' : y_pred})
    results = results.reset_index() #reset the index back to 0
    results = results.drop('index', axis = 1)#remove addditional index column created
    print(results)
    #bar chart for actual vs predicted. Shows first 100 entries.
    results[0:100].plot(kind = 'bar', figsize= (10, 8))
    plt.grid(which = 'major', linestyle = '-', linewidth = '0.5', color = 'green')
    plt.grid(which = 'minor', linestyle = ':', linewidth = '0.5', color = 'black')
    plt.title('Predicting vs Actual sale prices in millions $')
    plt.xlabel('Data')
    plt.ylabel('House Prices in millions ($)')
    plt.show()
    
#same as above 2 but using PCA
def svr3Lin(): 
    print("\nsvr3Lin")
    regressor = SVR(kernel = 'linear', degree = 1)
    X = df.drop('sale_price', axis = 1) #using all features
    y = df.sale_price #predicting sale price
    #Scale x
    sc_X = StandardScaler()
    X = sc_X.fit_transform(X)
    #Apply PCA to X
    pca = PCA(n_components = 4)#reduce to 4 dimensions for high variance
    pca.fit(X)
    xPCA = pca.transform(X)
    X_train, X_test, y_train, y_test = train_test_split(xPCA, y, test_size = 0.25, random_state = 7)
    regressor.fit(X_train, y_train)
    y_pred = regressor.predict(X_test)
    #Display the scores and mean results and RMSE.
    print(f"Accuracy Score: {regressor.score(X_test, y_test)}")
    print(f"R2 Score: {r2_score(y_test, y_pred)}")
    print('Mean Absolute Error: ', metrics.mean_absolute_error(y_test, y_pred))
    print('Mean Squared Error: ', metrics.mean_squared_error(y_test, y_pred))
    print('Mean: ', np.mean(y_test))
    print('Root Mean Squared Error: ', np.sqrt(metrics.mean_squared_error(y_test, y_pred)))
    #Create a dataframe to see the predicted results and compare with the expected
    results = pd.DataFrame({'Actual' : y_test, 'Predicted' : y_pred})
    results = results.reset_index() #reset the index back to 0
    results = results.drop('index', axis = 1)#remove addditional index column created
    print(results)
    #bar chart for actual vs predicted. Shows first 100 entries.
    results[0:100].plot(kind = 'bar', figsize= (10, 8))
    plt.grid(which = 'major', linestyle = '-', linewidth = '0.5', color = 'green')
    plt.grid(which = 'minor', linestyle = ':', linewidth = '0.5', color = 'black')
    plt.title('Predicting vs Actual sale prices in millions $')
    plt.xlabel('Data')
    plt.ylabel('House Prices in millions ($)')
    plt.show()
    
def svr3RBF(): #3rd best
    print("\nsvr3RBF")
    regressor = SVR(kernel = 'rbf', C = 10)
    X = df.drop('sale_price', axis = 1) #using all features
    y = df.sale_price #predicting sale price
    sc_X = StandardScaler()
    # Scale x and y (two scale objects)
    X = sc_X.fit_transform(X)
    pca = PCA(n_components = 4) #reduce to 4 dimensions
    pca.fit(X)
    xPCA = pca.transform(X)
    X_train, X_test, y_train, y_test = train_test_split(xPCA, y, test_size = 0.25, random_state = 7)
    regressor.fit(X_train, y_train)
    y_pred = regressor.predict(X_test)
    #Display the scores and mean results and RMSE.
    print(f"Accuracy Score: {regressor.score(X_test, y_test)}")
    print(f"R2 Score: {r2_score(y_test, y_pred)}")
    print('Mean Absolute Error: ', metrics.mean_absolute_error(y_test, y_pred))
    print('Mean Squared Error: ', metrics.mean_squared_error(y_test, y_pred))
    print('Mean: ', np.mean(y_test))
    print('Root Mean Squared Error: ', np.sqrt(metrics.mean_squared_error(y_test, y_pred)))
    #Create a dataframe to see the predicted results and compare with the expected
    results = pd.DataFrame({'Actual' : y_test, 'Predicted' : y_pred})
    results = results.reset_index() #reset the index back to 0
    results = results.drop('index', axis = 1)#remove addditional index column created
    print(results)
    #bar chart for actual vs predicted. Shows first 100 entries.
    results[0:100].plot(kind = 'bar', figsize= (10, 8))
    plt.grid(which = 'major', linestyle = '-', linewidth = '0.5', color = 'green')
    plt.grid(which = 'minor', linestyle = ':', linewidth = '0.5', color = 'black')
    plt.title('Predicting vs Actual sale prices in millions $')
    plt.xlabel('Data')
    plt.ylabel('House Prices in millions ($)')
    plt.show()
    
#Ordered by best to worst.
svr2RBF()
svr2Lin()
svr3RBF()
svr3Lin()
svrRBF()
svrLin()


#To determine the best number of components that the PCA should be set to obtain the best variance.
def pcaPlot():
    pca = PCA().fit(df)
    plt.plot(np.cumsum(pca.explained_variance_ratio_))
    plt.xlabel("Number of components")
    plt.ylabel("Cumulative explained variance")

pcaPlot()

"""
After running all 3 functions, it would appear that the function svr2RBF produces the best results out of the 6. 
I assumed that using PCA in svr3 functions would improve results, but it reduces the accuracy score and increases the RMSE.
The first 2 svr functions produces poorer results due to the fact that it only works gross square feet and not the rest of the features. 
RBF does appear to work better than using linear kernel which further suggests that the data set is non-linear.
I also used standard scaler on X to improve results as prior to using it, I was getting high RMSE values and very low accuracy with some 
values being predicted at negative values and having a predicted range of 30 and -30. So while an actual value was 0.1, it would be predicted 
as -10 sometimes.
If I attempt any function using the whole dataset without using scaler, it takes a long time to process. By simply applying scaler on X, it 
significantly reduces the processing time to a few minutes.
Overall, svr2RBF produces the best result having the lowest RMSE and the highest accuracy score. 
"""
