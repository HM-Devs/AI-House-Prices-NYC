# -*- coding: utf-8 -*-
"""
Created on Thu Nov 21 14:50:18 2019

@author: Junad
This script is an attempt to use Support Vector Classification on the dataset to perform
predictions on the dataset.
The results are not satisfactory in this instance. 

"""

import os
import pandas as pd
import numpy as np

from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.preprocessing import StandardScaler



#path = "../Dataset/NYC/Cleaned up sales/"
path = ""

filename_read = os.path.join(path, "nyc-rolling-sales.csv")
df = pd.read_csv(filename_read, na_values=['NA', ' -  ']) #making null values as NA

#converting date field values to dd-mm-yyyy
df['SALE DATE'] = pd.to_datetime(df['SALE DATE'], dayfirst=True)
#sorting by sale date
df = df.sort_values(by='SALE DATE', ascending=True)

"""
Removing certain types of buildings which are public buildings like hospitals as we 
want to focus on homes which anyone could purchase as opposed to warehouses and such
"""
#Encode building class category column as numerical to filter this column
leB = preprocessing.LabelEncoder() 
buildingEncode = leB.fit(df['BUILDING CLASS CATEGORY']) #fit the data
buildingEncode = leB.transform(df['BUILDING CLASS CATEGORY']) #transform/encode the data to numerical
df['BUILDING CLASS CATEGORY'] = buildingEncode #assign the encoded column to the dataset
#remove properties that have building class category of 21 and above
df = df[df['BUILDING CLASS CATEGORY'].astype('float') <= 18] #when encoding, 21 OFFICE BUILDINGS is encoded as 19. So 18 and less                       


"""Data filtering removing things we don't want to keep to use with the models."""
#Divide the sale price values by a million so the numbers aren't large
df['SALE PRICE'] = df['SALE PRICE'].div(1000000)
#drop the rows that have 0 as the sale price
df = df[df['SALE PRICE'] != 0] #$0 properties are those where the wnership was transfered to family members and not sold
df = df[df['GROSS SQUARE FEET'] != 0]
df = df[df['SALE PRICE'] != 0.00001]
#removing big sale price values because the scale of the graphs are too high for me
df = df[(df['SALE PRICE'] <= 10)]
#removing gross square feet numbers bigger than 2000000 cos the scale is too bigh
df = df[(df['GROSS SQUARE FEET'] <= 2000)]
#------------------------------------------------------------
"""
This is for the second dataframe where we reduce the columns and clean up further.
"""
#creating a new dataframe with the columns we feel are useful
col_borough = df['BOROUGH']
col_neighborhood = df['NEIGHBORHOOD'] 
col_buildingClassCat = df['BUILDING CLASS CATEGORY']
col_taxClassPresent = df['TAX CLASS AT PRESENT']
col_block = df['BLOCK']
col_lot = df['LOT']
col_buildingClassPresent = df['BUILDING CLASS AT PRESENT']
col_grossSqFt = df['GROSS SQUARE FEET']
col_yearBuilt = df['YEAR BUILT']
col_taxClassSale = df['TAX CLASS AT TIME OF SALE']
col_buildingClassSale = df['BUILDING CLASS AT TIME OF SALE']
col_salePrice = df['SALE PRICE']
col_saleDate = df['SALE DATE']

dfCon = pd.concat([col_borough, col_neighborhood, col_buildingClassCat, 
                   col_taxClassPresent, col_block, col_lot, col_buildingClassPresent, 
                   col_grossSqFt, col_yearBuilt, col_taxClassSale, col_buildingClassSale, 
                   col_salePrice, col_saleDate], axis = 1)

#converting date field values to dd-mm-yyyy
dfCon['SALE DATE'] = pd.to_datetime(dfCon['SALE DATE'], dayfirst=True)
#sorting by sale date
dfCon = dfCon.sort_values(by='SALE DATE', ascending=True)
#filling missing values with median for sale price and gross square feet
med = dfCon['SALE PRICE'].median()
dfCon['SALE PRICE'] = dfCon['SALE PRICE'].fillna(med) #this replaces all the NA  values in sale price with 530000 which is the median of the sale price column
med2 = dfCon['GROSS SQUARE FEET'].median()
dfCon['GROSS SQUARE FEET'] = dfCon['GROSS SQUARE FEET'].fillna(med2)

"""
Encoding the string categorical data and changing the data types to either categorical or numerical.
"""

dfEncode = dfCon
#Rename the columns to lower case so it's easier to type.
dfEncode.columns = ['borough', 'neighborhood', 'building_class_category',
       'tax_class_at_present', 'block', 'lot', 'building_class_at_present',
       'gross_square_feet', 'year_built', 'tax_class_at_time_of_sale',
       'building_class_at_time_of_sale', 'sale_price', 'sale_date']

"""
Encoding the string categorical data into numerical data so they can be used in the models.
The data types will be changed to numerical or categorical later.
"""
#Neighborhood
leN = preprocessing.LabelEncoder() #one variable for encoding neighborhood column
neighborEncode = leN.fit(dfEncode['neighborhood']) #fit the data
neighborEncode = leN.transform(dfEncode['neighborhood']) #transform/encode the data to numerical
dfEncode['neighborhood'] = neighborEncode #replace the values in neighborhood column with the encoded values
#Tax Class at present
leT = preprocessing.LabelEncoder()
taxEncode = leT.fit(dfEncode['tax_class_at_present'])
taxEncode = leT.transform(dfEncode['tax_class_at_present'])
dfEncode['tax_class_at_present'] = taxEncode
#Building class at present
leBP = preprocessing.LabelEncoder() 
buildingPEncode = leBP.fit(dfEncode['building_class_at_present'])
buildingPEncode = leBP.transform(dfEncode['building_class_at_present'])
dfEncode['building_class_at_present'] = buildingPEncode
#Building class at time of sale
leBS = preprocessing.LabelEncoder()
buildingTEncode = leBS.fit(dfEncode['building_class_at_time_of_sale'])
buildingTEncode = leBS.transform(dfEncode['building_class_at_time_of_sale'])
dfEncode['building_class_at_time_of_sale'] = buildingTEncode
#Sale date
leSD = preprocessing.LabelEncoder() #sale date
dateEncode = leSD.fit(dfEncode['sale_date']) #fit the data
dateEncode = leSD.transform(dfEncode['sale_date']) #transform/encode the data to numerical
dfEncode['sale_date'] = dateEncode 

#Converting data types to numerical and categorical as couldn't be done in df and move to dfEncode
dfEncode['sale_price'] = pd.to_numeric(dfEncode['sale_price'], errors = 'coerce')
dfEncode['gross_square_feet'] = pd.to_numeric(dfEncode['gross_square_feet'], errors = 'coerce')
#categorical data
dfEncode['borough'] = dfEncode['borough'].astype('category')
dfEncode['neighborhood'] = dfEncode['neighborhood'].astype('category')
dfEncode['building_class_category'] = dfEncode['building_class_category'].astype('category')

dfEncode['tax_class_at_present'] = dfEncode['tax_class_at_present'].astype('category')
dfEncode['tax_class_at_time_of_sale'] = dfEncode['tax_class_at_time_of_sale'].astype('category')
dfEncode['building_class_at_present'] = dfEncode['building_class_at_present'].astype('category')
dfEncode['building_class_at_time_of_sale'] = dfEncode['building_class_at_time_of_sale'].astype('category')

df = dfEncode #assign the cleaned up data to the main dataframe

#separate dataframes for each borough.
df1 = df[df.borough==1] #Manhattan
df2 = df[df.borough==2] #Bronx
df3 = df[df.borough==3] #Brooklyn
df4 = df[df.borough==4] #Queens
df5 = df[df.borough==5] #Staten Island

#SVM stuff
#-----------------------------------------------------------------------------------
#plot the confusion matrices
def plot_confusion_matrix(cm, names, title='Confusion Matrix', cmap=plt.cm.Blues):
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar(fraction=0.05)
    tick_marks = np.arange(len(names))
    plt.xticks(tick_marks, names, rotation=45)
    plt.yticks(tick_marks, names)
    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    

def cm_plot1(df, col, ker, reg, gam):
    X = df.drop(col, axis=1) #we'll use everything but the col to predict it
    y = df[col] #predicting col
    areas = y.unique()
    sc_X = StandardScaler()
    # Scale x and y (two scale objects)
    X = sc_X.fit_transform(X)
    #Split the data into training and testing
    X_train, X_test, y_train, y_test = train_test_split(    
    X, y, test_size=0.25, random_state=42) 
    svm_model = SVC(kernel=ker, C=reg, gamma = gam).fit(X, y)
    y_pred = svm_model.predict(X_test)
    print('Accuracy: %.2f' % accuracy_score(y_test, y_pred))
    cm = confusion_matrix(y_test, y_pred)
    np.set_printoptions(precision=2)
    print('Confusion Matrix, without normalisation')
    print(cm)
    #normalised confusion matrix
    cm_normalised = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
    print('Normalised confusion matrix')
    print(cm_normalised)
    plt.figure()
    plot_confusion_matrix(cm_normalised, areas, title='Normalised confusion matrix')
    plt.show()

#Using the training data to fit the model yields different results.
def cm_plot2(df, col, ker, reg, gam):
    X = df.drop(col, axis=1) #we'll use everything but the col to predict it
    y = df[col] #predicting col
    areas = y.unique()
    sc_X = StandardScaler()
    # Scale x and y (two scale objects)
    X = sc_X.fit_transform(X)
    #Split the data into training and testing
    X_train, X_test, y_train, y_test = train_test_split(    
    X, y, test_size=0.25, random_state=42) 
    svm_model = SVC(kernel=ker, C=reg, gamma = gam).fit(X_train, y_train)
    y_pred = svm_model.predict(X_test)
    print('Accuracy: %.2f' % accuracy_score(y_test, y_pred))
    cm = confusion_matrix(y_test, y_pred)
    np.set_printoptions(precision=2)
    print('Confusion Matrix, without normalisation')
    print(cm)
    #normalised confusion matrix
    cm_normalised = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
    print('Normalised confusion matrix')
    print(cm_normalised)
    plt.figure()
    plot_confusion_matrix(cm_normalised, areas, title='Normalised confusion matrix')
    plt.show()

"""
As can be seen when running this, the matrices seem to be getting a weird input resulting in
an unclear confusion matrix. 
In some cases, it seems the input used is only a small amount and thus not even filling the space
of the matrix. Adjusting the test size does affect this, but it doesn't seem feasible and wouldn't
maintain consistency across the models.
While fitting the model on just X and y produced a diagonal line initially, fitting it on the training
set made things even more messy.
Since the dataset is huge with over 10000 values, plotting it all on the matrix proves unreadable.
However there is a diagonal line but it's not as clear as anticipated.
fitting it on the training data as expected yields different results.
Because I could not understand why, this was not completed to a satisfactory degree. 
"""
cm_plot1(df1, 'neighborhood', 'rbf', 1, 'auto')
cm_plot1(df, 'neighborhood', 'rbf', 1, 'auto')
cm_plot1(df, 'borough', 'rbf', 1, 'auto')
cm_plot2(df1, 'neighborhood', 'rbf', 1, 'auto')
cm_plot2(df, 'neighborhood', 'rbf', 1, 'auto')
cm_plot2(df, 'borough', 'rbf', 1, 'auto')