"""

This script is for decision tree regression.

This script is used to predict the sale price based on the rest of our features.

@author: Usaamah
"""

import os
import pandas as pd
import numpy as np

from sklearn import preprocessing

from sklearn import metrics

#from sklearn.preprocessing import LabelEncoders
from sklearn.tree import DecisionTreeRegressor 
from sklearn.metrics import r2_score
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
#from sklearn.metrics import root_mean_squared_error

from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split

import matplotlib.pyplot as plt


path = ""

filename_read = os.path.join(path, "nyc-rolling-sales.csv")

df = pd.read_csv(filename_read, na_values=['NA', ' -  ']) #making null values as NA

#converting date field values to yyyy-mm-dd
df['SALE DATE'] = pd.to_datetime(df['SALE DATE'], dayfirst=True)
#sorting by sale date
df = df.sort_values(by='SALE DATE', ascending=True)

#Encoding building class category to numerical to remove some data easily. 
leB = preprocessing.LabelEncoder() #one variable for encoding building_class_category column
buildingEncode = leB.fit(df['BUILDING CLASS CATEGORY']) #fit the data
buildingEncode = leB.transform(df['BUILDING CLASS CATEGORY']) #transform/encode the data to numerical
df['BUILDING CLASS CATEGORY'] = buildingEncode
#Removing properties with building class category of over 21 to keep the data relevant to house prices
#and remove public buildings like hospitals from the data.
df = df[df['BUILDING CLASS CATEGORY'].astype('float') <= 18] #when encoding, 21 OFFICE BUILDINGS is encoded as 19. So 18 and less                       

#----------------------------------------------------------------------------------------------------------
#This is for the second dataframe where we reduce the columns and clean up further
#creating a new dataframe with not all of the existing columns
col_borough = df['BOROUGH']
col_neighborhood = df['NEIGHBORHOOD'] 
col_buildingClassCat = df['BUILDING CLASS CATEGORY']
col_taxClassPresent = df['TAX CLASS AT PRESENT']
col_block = df['BLOCK']
col_lot = df['LOT']
col_buildingClassPresent = df['BUILDING CLASS AT PRESENT']
col_grossSqFt = df['GROSS SQUARE FEET']
col_yearBuilt = df['YEAR BUILT']
col_taxClassSale = df['TAX CLASS AT TIME OF SALE']
col_buildingClassSale = df['BUILDING CLASS AT TIME OF SALE']
col_salePrice = df['SALE PRICE']
col_saleDate = df['SALE DATE']

dfCon = pd.concat([col_borough, col_neighborhood, col_buildingClassCat, col_taxClassPresent, 
                   col_block, col_lot, col_buildingClassPresent, col_grossSqFt, col_yearBuilt, 
                   col_taxClassSale, col_buildingClassSale, col_salePrice, col_saleDate], axis = 1)
     
#converting date field values to yyyy-mm-dd
dfCon['SALE DATE'] = pd.to_datetime(dfCon['SALE DATE'], dayfirst=True)
#sorting by sale date
dfCon = dfCon.sort_values(by='SALE DATE', ascending=True)
#filling missing values with median. Just Sale price
med = dfCon['SALE PRICE'].median()
dfCon['SALE PRICE'] = dfCon['SALE PRICE'].fillna(med) #this replaces all the NA  values in sale price with 530000 which is the median of the sale price column

dfEncode = dfCon

#renaming the columns so it is easier to visualise and type
dfEncode.columns = ['borough', 'neighborhood', 'building_class_category',
       'tax_class_at_present', 'block', 'lot', 'building_class_at_present',
       'gross_square_feet', 'year_built', 'tax_class_at_time_of_sale',
       'building_class_at_time_of_sale', 'sale_price', 'sale_date']

#Encoding string data to numerical ----------------------------------------------------------------------------------------------------
#Neighborhood
leN = preprocessing.LabelEncoder() #one variable for encoding neighborhood column
neighborEncode = leN.fit(dfEncode['neighborhood']) #fit the data
neighborEncode = leN.transform(dfEncode['neighborhood']) #transform/encode the data to numerical
dfEncode['neighborhood'] = neighborEncode #replace the values in neighborhood column with the encoded values
#Tax class at present
leT = preprocessing.LabelEncoder()
taxClassEncode = leT.fit(dfEncode['tax_class_at_present']) 
taxClassEncode = leT.transform(dfEncode['tax_class_at_present']) 
dfEncode['tax_class_at_present'] = taxClassEncode
#Building class at present
leBP = preprocessing.LabelEncoder()
buildingCP = leBP.fit(dfEncode['building_class_at_present']) 
buildingCP = leBP.transform(dfEncode['building_class_at_present']) 
dfEncode['building_class_at_present'] = buildingCP
#Building class at time of sale
leBT = preprocessing.LabelEncoder()
buildingCT = leBT.fit(dfEncode['building_class_at_time_of_sale']) 
buildingCT = leBT.transform(dfEncode['building_class_at_time_of_sale']) 
dfEncode['building_class_at_time_of_sale'] = buildingCT
#Sale date
leSD = preprocessing.LabelEncoder() #sale date
dateEncode = leSD.fit(dfEncode['sale_date']) #fit the data
dateEncode = leSD.transform(dfEncode['sale_date']) #transform/encode the data to numerical
dfEncode['sale_date'] = dateEncode

#Converting relevant columns to be categorical or numerical data types for the models to use. 
dfEncode['sale_price'] = pd.to_numeric(dfEncode['sale_price'], errors = 'coerce')
dfEncode['gross_square_feet'] = pd.to_numeric(dfEncode['gross_square_feet'], errors = 'coerce')
#categorical data
dfEncode['borough'] = dfEncode['borough'].astype('category')
dfEncode['neighborhood'] = dfEncode['neighborhood'].astype('category')
dfEncode['building_class_category'] = dfEncode['building_class_category'].astype('category')

dfEncode['tax_class_at_present'] = dfEncode['tax_class_at_present'].astype('category')
dfEncode['tax_class_at_time_of_sale'] = dfEncode['tax_class_at_time_of_sale'].astype('category')
dfEncode['building_class_at_present'] = dfEncode['building_class_at_present'].astype('category')
dfEncode['building_class_at_time_of_sale'] = dfEncode['building_class_at_time_of_sale'].astype('category')

#assign the cleaned up dataset to the main dataframe. 
df = dfEncode

## Remove columns with intangible data.
df = df[df['sale_price'].notnull()]
df['sale_price'] = df['sale_price'].div(1000000)
df = df[df['sale_price'] !=0]
df = df[df['gross_square_feet'] !=0]
df = df[df['year_built'] !=0]
df = df[df.sale_price != 0.00001]
df = df[(df['gross_square_feet'] <= 2000)]
df = df[(df['sale_price'] <= 10)]

print ('AA {}'.format(len(df)))

#separate dataframes for each borough.
df1 = df[df.borough==1] #Manhattan
df2 = df[df.borough==2] #Bronx
df3 = df[df.borough==3] #Brooklyn
df4 = df[df.borough==4] #Queens
df5 = df[df.borough==5] #Staten Island


#Decision tree stuff
#---------------------------------------------------------------------------------------------------------------
result = []
for x in df.columns:
    if x != 'sale_price':
        result.append(x)

X = df[result].values
y = df['sale_price'].values

#Training and testing split
#--------------------------------------------------------------------------------------------------------
X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=0)#Split data into testing and training sets

#DecisionTreeRegressor and fit regressor tree
regressor = DecisionTreeRegressor(criterion='mse',  max_depth=9, min_samples_split=4)
regressor.fit(X_train, y_train)
print("R-squared on training set={}".format(regressor.score(X_train, y_train)))

#Predict new value
y_pred = regressor.predict(X_test)
print("R-squared on prediction={}".format(r2_score(y_test, y_pred)))





#dataframe displaying actual price compared to predicted
prices = pd.DataFrame({'Actual':y_test, 'Predicted':y_pred})
df_head = prices.head(5000)
print(df_head)
#dflist = df.columns.tolist()

#print('Accuracy:', regressor.score(y_test, y_pred)*100)
print('\nMean:', np.mean(y_test))
print('Mean Absolute Error:', metrics.mean_absolute_error(y_test, y_pred))
print('Mean Squared Error:', metrics.mean_squared_error(y_test, y_pred))
print('Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(y_test, y_pred)))



#Mean absolute error of leaf nodes in steps of 100
#----------------------------------------------------------------------------------------------------------
mean_absolute_error(y_test, y_pred)

def get_mae(leaf_nodes, X_train, X_test, y_train, y_test):
    regressor = DecisionTreeRegressor(criterion="mse", max_depth=9, min_samples_split=4,
                                      max_leaf_nodes=leaf_nodes, random_state=0)
    
    regressor.fit(X_train, y_train)
    y_pred = regressor.predict(X_test)
    mae = mean_absolute_error(y_test, y_pred)
    return(mae)
    
#Prints out the mae for each leaf node. Starting from 2, going to 5000 in steps of 500.
for leaf_nodes in np.arange(2, 5000, 500):
    mae = get_mae(leaf_nodes, X_train, X_test, y_train, y_test)
    print(leaf_nodes, "  >>>>>>>>>> ", mae)

#Chart for gross square feet vs sale price
#------------------------------------------------------------------------------------------------------------
plt.scatter(y_test, y_pred, color='green', linewidth = '0.5')
plt.xlabel('House Prices In Million ($)')
plt.ylabel('Gross Square Feet')
plt.show()

#Chart displaying actual vs predicted sale prices
#-----------------------------------------------------------------------------------------------------------
def pred_chart(test, pred, sort=True):
    pred_chart = pd.DataFrame({'test': test.flatten(), 'pred': pred})
    if sort:
        pred_chart.sort_values(by=['test'], inplace=True)
    plt.plot(pred_chart['pred'].tolist(), label='prediction')
    plt.plot(pred_chart['test'].tolist(), label='actual')
    plt.ylabel('House Prices In Million ($)')
    plt.xlabel('Entries from Dataset')
    plt.legend()

pred_chart(y_test, y_pred.flatten(), sort=True)


X = df.drop('sale_price', axis = 1)
y = df.sale_price

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)

def rmse(y_test, y_pred):
    mean = np.mean(y_test)
    mae = metrics.mean_absolute_error(y_test, y_pred)
    mse = metrics.mean_squared_error(y_test, y_pred)
    rmse1 = np.sqrt(metrics.mean_squared_error(y_test, y_pred))
    rmse2 = np.sqrt(mean_squared_error(y_test, y_pred))
    print('\nMean:', mean)
    print('Mean Absolute Error: ', mae )
    print('Mean Squared Error: ', mse)
    print('Root Mean Squared Error: ', rmse1)
    print('Root Mean Squared Error: ', rmse2)


#Grid_search
#----------------------------------------------------------------------------------------------------------
param_grid = {'criterion': ['mse','mae'],
              'max_depth':[9],
              'max_leaf_nodes':[5000],
              'min_samples_split':[4],
              }
    
grid_regressor = GridSearchCV(regressor, param_grid, cv = 10, scoring = 'neg_mean_squared_error', verbose = 0, n_jobs = 1)
grid_regressor.fit(X, y)
    
print('R-squared: {}'.format(grid_regressor.best_score_))
print('Best Hyperparameters: \n{}'.format(grid_regressor.best_params_))

grid_model =  pd.DataFrame(data=grid_regressor.cv_results_)
print(grid_model.head())

