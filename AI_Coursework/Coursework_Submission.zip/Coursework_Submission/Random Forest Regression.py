# -*- coding: utf-8 -*-
"""
Created on Wed Dec 5 14:17:54 2019
This script is for random forest regression.
It consists of multiple version coded differently using different features or number of trees
to predict the sale price. Each version has different accuracy scores and RMSE values.
They also produce a bar chart showing the actual result 
and the predicted results upon executing the model.

The script is run by calling each function in order of best to worst results.

The script was created based on a Youtube tutorial.
https://www.youtube.com/watch?v=5HboxUpSPvg.
The tutorial provided in lecture 5 was also used as the basis of the script.

@author: Junad
"""

import os
import pandas as pd
import numpy as np
from sklearn import preprocessing
from sklearn.ensemble import RandomForestRegressor

from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from sklearn import metrics
from sklearn.metrics import r2_score

path = ""

filename_read = os.path.join(path, "nyc-rolling-sales.csv")
df = pd.read_csv(filename_read, na_values=['NA', ' -  ']) #making null values as NA

#converting date field values to dd-mm-yyyy
df['SALE DATE'] = pd.to_datetime(df['SALE DATE'], dayfirst=True)
#sorting by sale date
df = df.sort_values(by='SALE DATE', ascending=True)

"""
Removing certain types of buildings which are public buildings like hospitals as we 
want to focus on homes which anyone could purchase as opposed to warehouses and such
"""
#Encode building class category column as numerical to filter this column
leB = preprocessing.LabelEncoder() 
buildingEncode = leB.fit(df['BUILDING CLASS CATEGORY']) #fit the data
buildingEncode = leB.transform(df['BUILDING CLASS CATEGORY']) #transform/encode the data to numerical
df['BUILDING CLASS CATEGORY'] = buildingEncode #assign the encoded column to the dataset
#remove properties that have building class category of 21 and above
df = df[df['BUILDING CLASS CATEGORY'].astype('float') <= 18] #when encoding, 21 OFFICE BUILDINGS is encoded as 19. So 18 and less                       


"""Data filtering removing things we don't want to keep to use with the models."""
#Divide the sale price values by a million so the numbers aren't large
df['SALE PRICE'] = df['SALE PRICE'].div(1000000)
#drop the rows that have 0 as the sale price
df = df[df['SALE PRICE'] != 0] #$0 properties are those where the wnership was transfered to family members and not sold
df = df[df['GROSS SQUARE FEET'] != 0]
df = df[df['SALE PRICE'] != 0.00001]
#removing big sale price values because the scale of the graphs are too high for me
df = df[(df['SALE PRICE'] <= 10)]
#removing gross square feet numbers bigger than 2000 cos the scale is too bigh
df = df[(df['GROSS SQUARE FEET'] <= 2000)]
#------------------------------------------------------------
"""
This is for the second dataframe where we reduce the columns and clean up further.
"""
#creating a new dataframe with the columns we feel are useful
col_borough = df['BOROUGH']
col_neighborhood = df['NEIGHBORHOOD'] 
col_buildingClassCat = df['BUILDING CLASS CATEGORY']
col_taxClassPresent = df['TAX CLASS AT PRESENT']
col_block = df['BLOCK']
col_lot = df['LOT']
col_buildingClassPresent = df['BUILDING CLASS AT PRESENT']
col_grossSqFt = df['GROSS SQUARE FEET']
col_yearBuilt = df['YEAR BUILT']
col_taxClassSale = df['TAX CLASS AT TIME OF SALE']
col_buildingClassSale = df['BUILDING CLASS AT TIME OF SALE']
col_salePrice = df['SALE PRICE']
col_saleDate = df['SALE DATE']

dfCon = pd.concat([col_borough, col_neighborhood, col_buildingClassCat, 
                   col_taxClassPresent, col_block, col_lot, col_buildingClassPresent, 
                   col_grossSqFt, col_yearBuilt, col_taxClassSale, col_buildingClassSale, 
                   col_salePrice, col_saleDate], axis = 1)

#converting date field values to dd-mm-yyyy
dfCon['SALE DATE'] = pd.to_datetime(dfCon['SALE DATE'], dayfirst=True)
#sorting by sale date
dfCon = dfCon.sort_values(by='SALE DATE', ascending=True)
#filling missing values with median for sale price and gross square feet
med = dfCon['SALE PRICE'].median()
dfCon['SALE PRICE'] = dfCon['SALE PRICE'].fillna(med) #this replaces all the NA  values in sale price with 530000 which is the median of the sale price column
med2 = dfCon['GROSS SQUARE FEET'].median()
dfCon['GROSS SQUARE FEET'] = dfCon['GROSS SQUARE FEET'].fillna(med2)

"""
Encoding the string categorical data and changing the data types to either categorical or numerical.
"""

dfEncode = dfCon
#Rename the columns to lower case so it's easier to type.
dfEncode.columns = ['borough', 'neighborhood', 'building_class_category',
       'tax_class_at_present', 'block', 'lot', 'building_class_at_present',
       'gross_square_feet', 'year_built', 'tax_class_at_time_of_sale',
       'building_class_at_time_of_sale', 'sale_price', 'sale_date']

"""
Encoding the string categorical data into numerical data so they can be used in the models.
The data types will be changed to numerical or categorical later.
"""
#Neighborhood
leN = preprocessing.LabelEncoder() #one variable for encoding neighborhood column
neighborEncode = leN.fit(dfEncode['neighborhood']) #fit the data
neighborEncode = leN.transform(dfEncode['neighborhood']) #transform/encode the data to numerical
dfEncode['neighborhood'] = neighborEncode #replace the values in neighborhood column with the encoded values
#Tax Class at present
leT = preprocessing.LabelEncoder()
taxEncode = leT.fit(dfEncode['tax_class_at_present'])
taxEncode = leT.transform(dfEncode['tax_class_at_present'])
dfEncode['tax_class_at_present'] = taxEncode
#Building class at present
leBP = preprocessing.LabelEncoder() 
buildingPEncode = leBP.fit(dfEncode['building_class_at_present'])
buildingPEncode = leBP.transform(dfEncode['building_class_at_present'])
dfEncode['building_class_at_present'] = buildingPEncode
#Building class at time of sale
leBS = preprocessing.LabelEncoder()
buildingTEncode = leBS.fit(dfEncode['building_class_at_time_of_sale'])
buildingTEncode = leBS.transform(dfEncode['building_class_at_time_of_sale'])
dfEncode['building_class_at_time_of_sale'] = buildingTEncode
#Sale date
leSD = preprocessing.LabelEncoder() #sale date
dateEncode = leSD.fit(dfEncode['sale_date']) #fit the data
dateEncode = leSD.transform(dfEncode['sale_date']) #transform/encode the data to numerical
dfEncode['sale_date'] = dateEncode 

#Converting data types to numerical and categorical as couldn't be done in df and move to dfEncode
dfEncode['sale_price'] = pd.to_numeric(dfEncode['sale_price'], errors = 'coerce')
dfEncode['gross_square_feet'] = pd.to_numeric(dfEncode['gross_square_feet'], errors = 'coerce')
#categorical data
dfEncode['borough'] = dfEncode['borough'].astype('category')
dfEncode['neighborhood'] = dfEncode['neighborhood'].astype('category')
dfEncode['building_class_category'] = dfEncode['building_class_category'].astype('category')

dfEncode['tax_class_at_present'] = dfEncode['tax_class_at_present'].astype('category')
dfEncode['tax_class_at_time_of_sale'] = dfEncode['tax_class_at_time_of_sale'].astype('category')
dfEncode['building_class_at_present'] = dfEncode['building_class_at_present'].astype('category')
dfEncode['building_class_at_time_of_sale'] = dfEncode['building_class_at_time_of_sale'].astype('category')

df = dfEncode #assign the cleaned up data to the main dataframe

#separate dataframes for each borough.
df1 = df[df.borough==1] #Manhattan
df2 = df[df.borough==2] #Bronx
df3 = df[df.borough==3] #Brooklyn
df4 = df[df.borough==4] #Queens
df5 = df[df.borough==5] #Staten Island

"""
Here is where I attempt to do random forest regression.
I did 5 attempts doing different things each time.
rfr. Choosing the number of decision trees to predict a single value of a single feature. e.g. predict the sale price for X gross square feet.
rfr2. Using a single feature and predicting the test data portion of that feature. 100 trees
rfr3. Same as 2 but using 200 trees.
rfr4. Using all features to predict sale price.
rfr5. Same as rfr4 but using PCA.
"""

def rfr(col, trees, predict, draw): #number of trees, gross sqft to predict sale price, draw grid or not
    print("rfr1")
    X = df[col].values.reshape(-1, 1) 
    y = df['sale_price']
    regressor = RandomForestRegressor(n_estimators = trees, random_state = 0)
    regressor.fit(X, y)
    y_pred = regressor.predict(X)
    print(f"Predicted result: {y_pred}")
    results = pd.DataFrame({'Actual' : y, 'Predicted' : y_pred})
    print(results)
    print("Accuracy score: ", regressor.score(X, y))
    mean = np.mean(y)
    rmse = np.sqrt(metrics.mean_squared_error(y, y_pred))
    print("Mean: ", mean)
    print("RMSE: ", rmse)
    #visualise the results
    if (draw == 1):
        X_grid = np.arange(min(X), max(X), 0.1)
        X_grid = X_grid.reshape((len(X_grid), 1))
        plt.scatter(X, y, color = 'red')
        plt.plot(X_grid, regressor.predict(X_grid), color = 'blue')
        plt.title('RFR Predicting sale price')
        plt.xlabel('Gross Square Feet')
        plt.ylabel('Sale price')
        plt.show()

def rfr2(col):
    print("rfr2")
    X = df[col].values.reshape(-1, 1)
    y = df['sale_price']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 7)
    nums = []
    for i in range(10, 100, 10): 
        regressor = RandomForestRegressor(n_estimators = i, random_state = 0)
        regressor.fit(X_train, y_train)
        y_pred = regressor.predict(X_test)
        score = regressor.score(X_test, y_test)
        r2score = r2_score(y_test, y_pred)
        mae = metrics.mean_absolute_error(y_test, y_pred)
        mse = metrics.mean_squared_error(y_test, y_pred)
        mean = np.mean(y_test)
        rmse = np.sqrt(metrics.mean_squared_error(y_test, y_pred))
        nums.append(i)
    print(f"Accuracy Score: {score}")
    print(f"R2 Score: {r2score}")
    print(f"Mean Absolute Error: {mae}")
    print(f"Mean Squared Error: {mse}")
    print(f"Other Mean: {mean}")
    print(f"RMSE: {rmse}")
    #bar chart for actual vs predicted
    results = pd.DataFrame({'Actual' : y_test, 'Predicted' : y_pred})
    results = results.reset_index() #reset the index back to 0
    results = results.drop('index', axis = 1)#remove additional index column created
    print(results)
    results[0:100].plot(kind = 'bar', figsize= (10, 8))
    plt.grid(which = 'major', linestyle = '-', linewidth = '0.5', color = 'green')
    plt.grid(which = 'minor', linestyle = ':', linewidth = '0.5', color = 'black')
    plt.title('Predicting vs Actual sale prices in millions $')
    plt.xlabel(col)
    plt.ylabel('House Prices in millions ($)')
    plt.show()
    
def rfr3(col):
    print("rfr3")
    X = df[col].values.reshape(-1, 1)
    y = df['sale_price']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 7)
    #accuracy_data = []
    nums = []
    for i in range(10, 200, 10): 
        regressor = RandomForestRegressor(n_estimators = i, random_state = 0)
        regressor.fit(X_train, y_train)
        y_pred = regressor.predict(X_test)
        score = regressor.score(X_test, y_test)
        r2score = r2_score(y_test, y_pred)
        mae = metrics.mean_absolute_error(y_test, y_pred)
        mse = metrics.mean_squared_error(y_test, y_pred)
        mean = np.mean(y_test)
        rmse = np.sqrt(metrics.mean_squared_error(y_test, y_pred))
        nums.append(i)
    print(f"Accuracy Score: {score}")
    print(f"R2 Score: {r2score}")
    print(f"Mean Absolute Error: {mae}")
    print(f"Mean Squared Error: {mse}")
    print(f"Other Mean: {mean}")
    print(f"RMSE: {rmse}")
    #bar chart for actual vs predicted
    results = pd.DataFrame({'Actual' : y_test, 'Predicted' : y_pred})
    results = results.reset_index() #reset the index back to 0
    results = results.drop('index', axis = 1)#remove addditional index column created
    print(results)
    results[0:100].plot(kind = 'bar', figsize= (10, 8))
    plt.grid(which = 'major', linestyle = '-', linewidth = '0.5', color = 'green')
    plt.grid(which = 'minor', linestyle = ':', linewidth = '0.5', color = 'black')
    plt.title('Predicting vs Actual sale prices in millions $')
    plt.xlabel(col)
    plt.ylabel('House Prices in millions ($)')
    plt.show()
    
#This one is using all features
def rfr4(): #best
    print("rfr4")
    X = df.drop('sale_price', axis = 1)
    y = df['sale_price']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 7)
    #accuracy_data = []
    nums = []
    for i in range(10, 300, 10): 
        regressor = RandomForestRegressor(n_estimators = i, random_state = 0)
        regressor.fit(X_train, y_train)
        y_pred = regressor.predict(X_test)
        score = regressor.score(X_test, y_test)
        r2score = r2_score(y_test, y_pred)
        mae = metrics.mean_absolute_error(y_test, y_pred)
        mse = metrics.mean_squared_error(y_test, y_pred)
        mean = np.mean(y_test)
        rmse = np.sqrt(metrics.mean_squared_error(y_test, y_pred))
        nums.append(i)
    print(f"Accuracy Score: {score}")
    print(f"R2 Score: {r2score}")
    print(f"Mean Absolute Error: {mae}")
    print(f"Mean Squared Error: {mse}")
    print(f"Other Mean: {mean}")
    print(f"RMSE: {rmse}")
    #bar chart for actual vs predicted
    results = pd.DataFrame({'Actual' : y_test, 'Predicted' : y_pred})
    results = results.reset_index() #reset the index back to 0
    results = results.drop('index', axis = 1)#remove addditional index column created
    print(results)
    results[0:100].plot(kind = 'bar', figsize= (10, 8))
    plt.grid(which = 'major', linestyle = '-', linewidth = '0.5', color = 'green')
    plt.grid(which = 'minor', linestyle = ':', linewidth = '0.5', color = 'black')
    plt.title('Predicting vs Actual sale prices in millions $')
    plt.xlabel('Data')
    plt.ylabel('House Prices in millions ($)')
    plt.show()


    
from sklearn.decomposition import PCA
#Using PCA
def rfr5(): #2nd best
    print("rfr5")
    X = df.drop('sale_price', axis = 1)
    y = df['sale_price']
    pca = PCA(n_components = 4) 
    pca.fit(X)
    xPCA = pca.transform(X)
    X_train, X_test, y_train, y_test = train_test_split(xPCA, y, test_size = 0.25, random_state = 7)
    nums = []
    for i in range(10, 300, 10): 
        regressor = RandomForestRegressor(n_estimators = i, random_state = 0)
        regressor.fit(X_train, y_train)
        y_pred = regressor.predict(X_test)
        score = regressor.score(X_test, y_test)
        r2score = r2_score(y_test, y_pred)
        mae = metrics.mean_absolute_error(y_test, y_pred)
        mse = metrics.mean_squared_error(y_test, y_pred)
        mean = np.mean(y_test)
        rmse = np.sqrt(metrics.mean_squared_error(y_test, y_pred))
        nums.append(i)
    print(f"Accuracy Score: {score}")
    print(f"R2 Score: {r2score}")
    print(f"Mean Absolute Error: {mae}")
    print(f"Mean Squared Error: {mse}")
    print(f"Other Mean: {mean}")
    print(f"RMSE: {rmse}")
    #print(f"Accuracy score: {accuracy_data}")
    #bar chart for actual vs predicted
    results = pd.DataFrame({'Actual' : y_test, 'Predicted' : y_pred})
    results = results.reset_index() #reset the index back to 0
    results = results.drop('index', axis = 1)#remove addditional index column created
    print(results)
    results[0:100].plot(kind = 'bar', figsize= (10, 8))
    plt.grid(which = 'major', linestyle = '-', linewidth = '0.5', color = 'green')
    plt.grid(which = 'minor', linestyle = ':', linewidth = '0.5', color = 'black')
    plt.title('Predicting vs Actual sale prices in millions $')
    plt.xlabel('Data')
    plt.ylabel('House Prices in millions ($)')
    plt.show()
    
#Ordered by best to worst
rfr4()
rfr5()
rfr3('gross_square_feet')   
rfr2('gross_square_feet')   
rfr('gross_square_feet', 100, 335500, 1) #Predicting sale price for 335500 gross sqft. Actual result is 38.39118

#To determine the best number of components that the PCA should be set to obtain the best variance.
def pcaPlot():
    pca = PCA().fit(df)
    plt.plot(np.cumsum(pca.explained_variance_ratio_))
    plt.xlabel("Number of components")
    plt.ylabel("Cumulative explained variance")

pcaPlot()

"""
Upon executing all 5 functions, it seems that rfr4 produces the best results, with a high accuracy score, and low RMSE value.
I initially tried to predict specifically the gross square feet and fit the model with that one feature. But it didn't produce
great results. So then I moved on to use all the features which yielded better results.
Again, I expected using PCA would help gain better results, but here it also did the opposite giving a higher RMSE
and a lower accuracy score than rfr4. 
The first attempt didn't use training or testing so doesn't provide accurate results. Moving on to using all features yielded
better results overall. 
"""