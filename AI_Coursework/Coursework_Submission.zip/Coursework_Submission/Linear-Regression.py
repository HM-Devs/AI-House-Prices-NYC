# -*- coding: utf-8 -*-
"""
Created on Thu Nov  7 12:24:39 2019

@author: Hamzah Malik - ACSF375.
This program contains code detailing how we used Linear Regression on our Dataset: Property prices in New York City across a 12 month period.
My submission will contain diagrams including:
    A heatmap using the seaborn library to map the correlation between my dataset's features.
    A pairplot of our dataset's property sale prices mapped against neighborhood, gross square feet and the year a property has been built.
    A barchart showcasing Linear Regression actual vs. predicted results for the sale price of a property against the rest of our features in DF.
    A chart showcasing predicted vs actual values from our dataset (using 300 values)
    A linear regression plot using predict labels against unknown data.
    I have also included the Coefficient and Interception of my regression diagram
    And the RMSE of Linear Regression against the Mean value.
"""

import os
#from sklearn import metrics
#from sklearn import preprocessing

# Import the modules

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

import warnings 
warnings.filterwarnings('ignore')
sns.set(style='white', context='notebook', palette='deep') 

import matplotlib.style as style
style.use('fivethirtyeight')

# Regression
from sklearn.linear_model import LinearRegression 

from sklearn.model_selection import train_test_split 
from sklearn.metrics import mean_squared_error

# Metrics
from sklearn import metrics
from sklearn import preprocessing

#path = "../Dataset/NYC/Cleaned up sales/"
path = ""

filename_read = os.path.join(path, "nyc-rolling-sales.csv")
#making null values as NA
df = pd.read_csv(filename_read, na_values=['NA', ' -  ']) 

#converting date field values to yyyy-mm-dd
df['SALE DATE'] = pd.to_datetime(df['SALE DATE'], dayfirst=True)

#sorting by sale date, as this previously was not done.
df = df.sort_values(by='SALE DATE', ascending=True)

#Encode building class category column as numerical to filter this column
leB = preprocessing.LabelEncoder() 
buildingEncode = leB.fit(df['BUILDING CLASS CATEGORY']) #fit the data
buildingEncode = leB.transform(df['BUILDING CLASS CATEGORY']) #transform/encode the data to numerical
df['BUILDING CLASS CATEGORY'] = buildingEncode #assign the encoded column to the dataset
#remove properties that have building class category of 21 and above
df = df[df['BUILDING CLASS CATEGORY'].astype('float') <= 18] #when encoding, 21 OFFICE BUILDINGS is encoded as 19. So 18 and less
#------------------------------------------------------------
#This is for the second dataframe where we reduce the columns and clean up further.
#creating a new dataframe with our main columns.
col_borough = df['BOROUGH']
col_neighborhood = df['NEIGHBORHOOD'] 
col_buildingClassCat = df['BUILDING CLASS CATEGORY']
col_taxClassPresent = df['TAX CLASS AT PRESENT']
col_block = df['BLOCK']
col_lot = df['LOT']
col_buildingClassPresent = df['BUILDING CLASS AT PRESENT']
col_grossSqFt = df['GROSS SQUARE FEET']
col_yearBuilt = df['YEAR BUILT']
col_taxClassSale = df['TAX CLASS AT TIME OF SALE']
col_buildingClassSale = df['BUILDING CLASS AT TIME OF SALE']
col_salePrice = df['SALE PRICE']
col_saleDate = df['SALE DATE']

#This is for our second DF where we clean up our columns and reduce our columns for a more consistent dataframe.
dfCon = pd.concat([col_borough, col_neighborhood, col_buildingClassCat, col_taxClassPresent, col_block, col_lot, col_buildingClassPresent, col_grossSqFt, col_yearBuilt, col_taxClassSale, col_buildingClassSale, col_salePrice, col_saleDate], axis = 1)
#converting date field values to yyyy-mm-dd
dfCon['SALE DATE'] = pd.to_datetime(dfCon['SALE DATE'], dayfirst=True)
#sorting by sale date
dfCon = dfCon.sort_values(by='SALE DATE', ascending=True)
#filling missing values with median.
med = dfCon['SALE PRICE'].median()
#this replaces all the NA  values in sale price with the median of the column.
dfCon['SALE PRICE'] = dfCon['SALE PRICE'].fillna(med) 

#Using the median of GSQ to replace NA values led to a much higher RMSE and therefore isn't used.
#med3 = dfCon['GROSS SQUARE FEET'].median()
#dfCon['GROSS SQUARE FEET'] = dfCon['GROSS SQUARE FEET'].fillna(med3)

#Encoding our categorical data into numerical data 
dfEncode = dfCon

#Renaming column names to lower case to reduce word spacing error (such as "SALE PRICE"). 
dfEncode.columns = ['borough', 'neighborhood', 'building_class_category',
       'tax_class_at_present', 'block', 'lot', 'building_class_at_present',
       'gross_square_feet', 'year_built', 'tax_class_at_time_of_sale',
       'building_class_at_time_of_sale', 'sale_price', 'sale_date']

#Neighborhood encoding 
leN = preprocessing.LabelEncoder() #one variable for encoding neighborhood column
neighborEncode = leN.fit(dfEncode['neighborhood']) #fit the data
neighborEncode = leN.transform(dfEncode['neighborhood']) #transform/encode the data to numerical
dfEncode['neighborhood'] = neighborEncode #replace the values in neighborhood column with the encoded values

#Tax Class at present encoding
leT = preprocessing.LabelEncoder()
taxEncode = leT.fit(dfEncode['tax_class_at_present'])
taxEncode = leT.transform(dfEncode['tax_class_at_present'])
dfEncode['tax_class_at_present'] = taxEncode

#Building class at present encoding 
leBP = preprocessing.LabelEncoder() 
buildingPEncode = leBP.fit(dfEncode['building_class_at_present'])
buildingPEncode = leBP.transform(dfEncode['building_class_at_present'])
dfEncode['building_class_at_present'] = buildingPEncode

#Building class at time of sale encoding
leBS = preprocessing.LabelEncoder()
buildingTEncode = leBS.fit(dfEncode['building_class_at_time_of_sale'])
buildingTEncode = leBS.transform(dfEncode['building_class_at_time_of_sale'])
dfEncode['building_class_at_time_of_sale'] = buildingTEncode

#Sale date encoding 
leSD = preprocessing.LabelEncoder() #sale date
dateEncode = leSD.fit(dfEncode['sale_date']) #fit the data
dateEncode = leSD.transform(dfEncode['sale_date']) #transform/encode the data to numerical
dfEncode['sale_date'] = dateEncode

#Encoding (further)
df = dfEncode

## Remove columns with missing SALE PRICES.
df = df[df['sale_price'].notnull()]

#Divide our 'sale_price' values by 1 Million. This stops data overlapping on our diagrams and is easier to read.
df['sale_price'] = df['sale_price'].div(1000000)

#Filtering out any properties with 0 for sale price, GSF, and year built.
df = df[df['sale_price'] !=0]
df = df[df['gross_square_feet'] !=0]
df = df[df['year_built'] !=0]

#Number of data values had $10 as sale price so these are also removed. (this is 0.00001 as its divided by a million)
df = df[df.sale_price != 0.00001]

#Any properties above 2000 million square feet and 10 million dollars are filtered out (these are typically not residential properties)
df = df[(df['gross_square_feet'] <= 2000)]
df = df[(df['sale_price'] <= 10)]

###dropping any NA values found, now everything is 'FALSE' for 'isNull'.
#df = df.dropna()
#print(df.isnull().any())

#Using a heatmap from Seaborn to map the similarities between my features
correlation = df.corr()
sns.heatmap(correlation)
correlation['sale_price'].sort_values(ascending=False)
plt.title('Correlation rate between our features:')

#plotting sale price against neighborhood, gross square feet and year built.
sns.pairplot(df, x_vars=['neighborhood','gross_square_feet', 'year_built'], y_vars='sale_price',size=7, aspect =1,kind='reg')
plt.title('Plotting Sale Price against Neighborhood,Gross Square Feet and Year Built')

#Only include types int32, int64 and float for our result.
df = df.select_dtypes(include=['int32', 'int64', 'float'])

#Setting up an empty array
result = []
for x in df.columns:
    if x!= 'sale_price':
        result.append(x)
#Any categories that aren't of type 'sale_price' are added into our result array and become our 'X' value.
X = df[result].values
#y is our sale price data values, as we plan on mapping our features against sale price.
y = df['sale_price'].values

#splitting up our data into testing and training
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

# building the model
model = LinearRegression()  
model.fit(X_train, y_train)

#calculate the predictions of the linear regression model
y_pred = model.predict(X_test)

#Build a new data frame with two columns, the actual values of the test data, and the predictions of the model
df_compare = pd.DataFrame({'Actual': y_test, 'Predicted': y_pred})
df_head = df_compare.head(100)
print(df_head)

#Setting up my initial diagram showcasing actual vs predicted sale prices against our DF features.
df_head.plot(kind='bar',figsize=(10,8))
plt.grid(which='major', linestyle='-', linewidth='0.5', color='green')
plt.grid(which='minor', linestyle=':', linewidth='0.5', color='black')
plt.title('Predicting Housing Prices vs Actual Prices ($)')
plt.ylabel('House Prices (Million $)')
plt.xlabel('Entries from Dataset')
plt.show()

#This is our mean value of our results and our RMSE. 
print('\nMean:', np.mean(y_test))
print('\nRoot Mean Squared Error:', np.sqrt(metrics.mean_squared_error(y_test, y_pred)))

# Regression chart which further shows our actual vs predicted results.
def chart_regression(pred, y, sort=True):
    t = pd.DataFrame({'pred': pred, 'y': y.flatten()})
    if sort:
        t.sort_values(by=['y'], inplace=True)
    plt.plot(t['y'].tolist(), label='expected')
    plt.plot(t['pred'].tolist(), label='prediction')
    plt.title('Predicting Housing Prices vs Actual Prices ($)')
    plt.ylabel('House Prices In Million ($)')
    plt.xlabel('Entries from Dataset')
    plt.legend()
    plt.show()


#This showcases how many values we are using for our y_pred and y_test.
chart_regression(y_pred[:300].flatten(),y_test[:300],sort=True)   


#Setting up a random state for our linear regression model.
rng = np.random.RandomState(0)
model = LinearRegression(fit_intercept=True)
print(model)

#Setting up a value of A based on our y predict. 
A = y_pred[:, np.newaxis]
A.shape

#Fitting our data against the model.
model.fit(A, y_test)
print(A.shape)
print(y_test.shape)

xfit = np.linspace(0, 1)
xfit.shape

Xfit = xfit[:, np.newaxis]
Xfit.shape

yfit = model.predict(Xfit)
plt.title('Regression Plot Results')
#This follows tutorial 3's example of plotting predict labels against unknown data.

#Scattering our y_prediction values and y_test values (predicted vs actual results)
plt.scatter(y_pred, y_test)
#Plotting our results using xfit and yfit.
plt.plot(xfit, yfit);


#printing the coefficient and interception of our model.
print('\nModel Coefficient:')
print(model.coef_)
print('\nModel Intercept:')
print(model.intercept_)

#showcase our columns and rows.
print ('\n', df.shape)

# Capture the necessary data
variables = df.columns

count = []

for variable in variables:
    length = df[variable].count()
    count.append(length)
    
count_pct = np.round(100 * pd.Series(count) / len(df), 2)

# RMSE
def rmse(y_test,y_pred):
      return np.sqrt(mean_squared_error(y_test,y_pred))  

linreg = LinearRegression()
linreg.fit(X_train, y_train)
Y_pred_lin = linreg.predict(X_test)


#The final result given from using Linear Regression using RMSE detection.
print('\nOur Mean value is:', np.mean(y_test))

print('\nOur RMSE using Linear Regression is:')
print(rmse(y_test,Y_pred_lin))